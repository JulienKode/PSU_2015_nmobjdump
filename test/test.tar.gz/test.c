int main(int ac)
{
	printf("toto\n");
	return (0);
}
